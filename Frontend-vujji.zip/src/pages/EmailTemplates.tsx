import axios from "axios";

const API = "http://localhost:5000";

export const getTemplates = async () => {
  const response = await axios.get(`${API}/email-templates`);
  return response.data.data;
};

export const createTemplate = async (data) => {
  const response = await axios.post(
    `${API}/email-templates`,
    data
  );

  return response.data;
};

export const deleteTemplate = async (id) => {
  const response = await axios.delete(
    `${API}/email-templates/${id}`
  );

  return response.data;
};